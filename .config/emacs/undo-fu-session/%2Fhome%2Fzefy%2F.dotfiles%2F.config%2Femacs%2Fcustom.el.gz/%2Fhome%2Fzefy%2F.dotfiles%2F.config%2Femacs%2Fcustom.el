((buffer-size . 696) (buffer-checksum . "6bea6d10b091ad84d636d03aa22ebe42c68bcc14"))
((emacs-buffer-undo-list (457 . 696) ("(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 )" . -457) (420 . 456) ("
" . -420) (420 . 421) (340 . 345) (" " . 340) (339 . 340) (267 . 415) (" " . 267) (1 . 268) ("(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(custom-safe-themes
   '(\"5244ba0273a952a536e07abaad1fdf7c90d7ebb3647f36269c23bfd1cf20b0b8\" default))
 '(package-selected-packages nil))" . -1) (t 27233 43018 989276 373000) (385 . 385) (385 . 624) ("(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 )" . -385) (348 . 384) ("
" . -348) (267 . 349) (" " . 267) (1 . 268) ("(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(package-selected-packages nil))" . -1) (t 27233 42954 352088 972000)) (emacs-pending-undo-list) (emacs-undo-equiv-table))